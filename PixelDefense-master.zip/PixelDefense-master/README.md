# PixelDefense

An HTML5/JS based tower defense game.

Collaborated with Michael Tarantino and Morgan Howard to produce for 
Oregon State University as a capstone project for a BS Comp Sci.

Currently hosted at https://www.edopedia.com/demo/pixeldefense

---

I've also created a complete list of best free open source HTML5 and JavaScript Games. I hope You'll love it.

Link: https://www.edopedia.com/blog/open-source-html5-and-javascript-games/
